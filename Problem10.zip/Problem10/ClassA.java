package Problem10;

public class ClassA extends ClassB{
    public static void main(String[] arg) {
        ClassB obj = new ClassB();
        obj.getvalue(10);
    }
}
