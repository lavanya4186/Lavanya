package Problem10;

public class ClassB {
    private int a;
    public int getvalue(int a1){
         a =a1;
        System.out.println("The value of Private value is --> "+a1);
         return a1;
             }

}
