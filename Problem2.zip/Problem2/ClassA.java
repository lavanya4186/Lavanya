package Problem2;


public class ClassA {
    private ClassB classInstance;

    public static void main(String args[])throws Exception {
        ClassB obj1=new ClassB();
        obj1.ClassB(20,25);
    }
}
