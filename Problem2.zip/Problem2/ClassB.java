package Problem2;

public class ClassB {

    public int a;
    public int b;

    public int ClassB(int a1,int b1) {

        a=a1;
        b=b1;
        System.out.println("The A value is:"+a1);
        System.out.println("The A value is:"+b1);
        return a1&b1;

    }

}
